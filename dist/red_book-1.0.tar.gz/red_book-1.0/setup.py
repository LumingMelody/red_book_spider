from distutils.core import setup

setup(
    name="red_book",
    version="1.0",
    author="luming",
    author_email="lumingmelody@gmai.com",
    py_modules=['red_book'],
)
