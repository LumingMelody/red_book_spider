import os
import re
from datetime import time

from lxml import etree
from openpyxl import Workbook
import requests
import pandas as pd
import json
import openpyxl

wb = Workbook()

ws = wb.active
ws1 = wb.create_sheet()

ws.append(
    [
        "粉丝数", "点赞数", "评论数", "收藏数"
    ]
)
# ws1.append([
#     "作者",
#     "文章链接",
#     "文章创建时间"
# ])

rd = pd.read_excel("D:/red_book/天猫奢品小红书koc数据统计.xlsx")
urls = rd["发布链接"]
cookie = "xhsTrackerId=ce649b22-f7c7-4686-c678-cc14d2c02782; xhsuid=wlNhixrVouQc1xH6; customerClientId=559394368134108; Hm_lvt_d0ae755ac51e3c5ff9b1596b0c09c826=1617094977,1617094988; xhs_spid.5dde=3af7c19f4aa1caf1.1617094977.3.1617182810.1617169544.18539bfe-2b0b-4e25-b645-1467a72badec; timestamp2=20210402ac7a7e53e407a4dc34dce466; timestamp2.sig=nPWPXBGFLYlE8OyXp8tlD2DsrG3LXn7sTrgb7cNG-AU; xhsTracker=url=noteDetail&xhsshare=CopyLink; smidV2=202104061553193a7c1a21482c01657352bb93535ed8a2007fa273ba4ff5ac0; extra_exp_ids=gif_exp1,ques_exp2"

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36",
    "cookie": cookie,
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'cache-control': 'max-age=0',
    'upgrade-insecure-requests': '1',
}


def get_red_book(red_url):
    response = requests.get(url=red_url, headers=headers, verify=False)
    if response:
        res = response.content.decode("utf-8")
        # re获取json 数据
        user_info_list = re.findall(r"<script>window.__INITIAL_SSR_STATE__[\s\S]*?{([\s\S]+?)}</script>", res)
        # print(user_info_list)
        # 完善 json 格式
        # for url_ in urls:
        #     url_ = url
        if user_info_list:
            user_info_str = user_info_list[0].strip()
            user_info_str = "{" + "{}".format(user_info_str) + "}"

            user_info_json = json.loads(user_info_str.replace('undefined', 'null'))
            if user_info_json:
                print(user_info_json)
                commentcount = user_info_json["NoteView"]["commentInfo"]["commentsTotal"]
                note_info = user_info_json["NoteView"]["noteInfo"]
                # print(note_info)
            # 文章信息
            if note_info:
                # details_dict = dict()
                # for n in note_info:
                # 收藏
                # author = n['user'][' nickname']
                # print(author)
                # details_dict['user_collected_num'] = n['likes']
                # # 文章发布时间
                # details_dict['note_time'] = n['time']
                # 评论
                # 粉丝数
                fans = note_info["user"]["fans"]
                # 点赞
                likes = note_info["likes"]
                # 收藏数
                collects = note_info["collects"]

                # note_url = "https://www.xiaohongshu.com/discovery/item/" + n['id']
                # ws1.append([author, note_url, time])
                # 用户相关信息0000
                # user_info = user_info_json["Main"]["userDetail"]
                # # print(user_info)
                # if user_info:
                #     fans = user_info['fans']
                #     likes = user_info['liked']
                #
                #     user_fans_level = ''
                # 用户粉丝数
                #         'user_url': '用户链接',
                #         'user_name': '用户名',
                #         'user_brief': '用户签名',
                #         'user_level': '用户等级',
                #         'user_location': '用户所在区域',
                #         'user_fans_num': '粉丝数',
                #         'user_fans_level': 'kol级别',
                #         'user_like_num': '获赞数',
                #         'user_follow_num': '关注数',
                #         'user_collected_num': '收藏数',
                #         'user_collect_like_num': '获赞与收藏数',
                #         'user_all_note_num': '笔记数',
                #         'note_url': '文章链接'
                # details_dict['user_fans_num'] = user_info['fans']
                # details_dict['user_follow_num'] = user_info['follows']
                # if user_info['fans'] < 50000:
                #     user_fans_level = "素人"
                # if user_info['fans'] > 50000 and user_info['fans'] < 200000:
                #     user_fans_level = "底部kol"
                # if user_info['fans'] > 200000 and user_info['fans'] < 1000000:
                #     user_fans_level = "腰部kol"
                # if user_info['fans'] > 1000000:
                #     user_fans_level = "头部kol"

                # details_dict['user_like_num'] = user_info['liked']
                # details_dict['user_location'] = user_info['location']
                # details_dict['user_brief'] = user_info['desc']
                # details_dict['user_all_note_num'] = user_info['notes']
                # user_collect_like_num = int(user_info['collected']) + int(
                #     user_info['liked'])
                # # details_dict['user_id'] = user_info['id']
                # # details_dict['user_name'] = user_info['nickname']
                # user_url = 'https://www.xiaohongshu.com/user/profile/{}'.format(
                #     user_info['id'])
                # details_dict['is_activate'] = 1
                # uid = uuid.uuid1().hex
                # details_dict['filter'] = 0

                # print("*"*20)
                # "用户链接", "用户名", "用户签名", "用户所在区域", "粉丝数", "kol级别", "获赞数", "关注数", "收藏数", "获赞与收藏数", "笔记数", "文章链接"
                ws.append([fans, likes, commentcount, collects])

    wb.save("D:/red_book/red_book2.xlsx")


#
# def save_to_excel(filename):
#     df = pd.read_json(filename)
#
#     wb = Workbook()
#     ws = wb.active
#     ws.append(
#         {
#             "用户链接", "用户名", "用户签名", "用户所在区域", "粉丝数", "kol级别", "获赞数", "关注数", "收藏数", "获赞与收藏数", "笔记数", "文章链接"
#         }
#     )
#     tables = []
#         tables.append(
#             {
#                 "用户链接": dfT[d]['user_url'],
#                 "用户名": dfT[d]['user_name'],
#                 "用户签名": dfT[d]['user_brief'],
#                 "用户所在区域": dfT[d]['user_location'],
#                 "粉丝数": dfT[d]['user_fans_num'],
#                 "kol级别": dfT[d]['user_fans_level'],
#                 "获赞数": dfT[d]['user_collect_like_num'],
#                 "关注数": dfT[d]['user_follow_num'],
#                 "收藏数": dfT[d]['user_collected_num'],
#                 "获赞与收藏数": dfT[d]['user_collect_like_num'],
#                 "笔记数": dfT[d]['user_all_note_num'],
#                 "文章链接": dfT[d]['note_url'],
#             }
#         )
#
#     wb.save('xhs.xlsx')


if __name__ == '__main__':
    # file_name = "D:/red_book/red_book_data.txt"
    for url in urls:
        get_red_book(url)
        # print(url)
    #     with open(file_name, "a", errors='ignore') as f:
    #         if not os.path.exists(file_name):
    #             os.mkdir(file_name)
    #         j = json.dumps(rs, ensure_ascii=False)
    #         for i in j:
    #             f.write(i)
